SELECT order_id,customer_id,ship_country FROM northwind_db.orders
WHERE ship_country = 'France' or ship_country='Belgium';