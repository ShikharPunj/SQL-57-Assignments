SELECT first_name,last_name,Hire_date FROM northwind_db.employees
Where title='Sales Representative' and country='USA';