SELECT a.Product_id ,a.Product_name,b.company_name FROM northwind_db.products as a
Left Join suppliers as b
ON a.supplier_id=b.supplier_id
