SELECT product_id,product_name FROM northwind_db.products
Where product_name like '%queso%';