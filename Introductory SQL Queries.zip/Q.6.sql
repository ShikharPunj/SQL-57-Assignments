SELECT supplier_id, Contact_Name, 
Contact_Title
 FROM northwind_db.suppliers
 where contact_title <> 'Marketing Manager';