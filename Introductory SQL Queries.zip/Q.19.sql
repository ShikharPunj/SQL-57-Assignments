SELECT a.order_id,a.order_date,b.company_name FROM northwind_db.orders as a
Inner Join shippers as b 
On a.ship_via=b.shipper_id
Where order_id < 10300
Order by order_id;
