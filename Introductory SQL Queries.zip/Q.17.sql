SELECT contact_title,Count(contact_title) as b FROM northwind_db.customers
Group by contact_title
Order by Count(contact_title) desc
