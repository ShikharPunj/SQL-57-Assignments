SELECT Order_date FROM northwind_db.orders
Order by order_date
Limit 1


