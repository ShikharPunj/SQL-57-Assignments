SELECT first_name,last_name,hire_date FROM northwind_db.employees
Where title = 'Sales Representative'; 
