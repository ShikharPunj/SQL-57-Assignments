SELECT 
Order_id,Product_ID, round(Unit_price,2) as Unit_Price,Quantity,(round(Unit_price,2)*Quantity) as Total_price 
FROM 
northwind_db.order_details
Order by order_id,product_id;
