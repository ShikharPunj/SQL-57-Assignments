SELECT first_name,last_name,title,birth_date FROM northwind_db.employees
Order by birth_date asc;