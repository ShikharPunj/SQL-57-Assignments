SELECT first_name,last_name,title,date_format(birth_date,'%m-%d-%y') as Birthdate FROM northwind_db.employees
Order by birth_date asc;
