SELECT Distinct(Country)FROM northwind_db.customers;
