SELECT order_id,order_date FROM northwind_db.orders
Where employee_id = 5;