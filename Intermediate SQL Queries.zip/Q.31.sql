with cte as
    (Select customers.customer_id
    from customers
    where customer_id not in 
        (select orders.customer_id from orders where orders.employee_id = '4'))
select *  
 from cte left join
    (select Customer_ID from Orders where orders.employee_id = '4') O
     on cte.Customer_ID = O.Customer_ID
     
