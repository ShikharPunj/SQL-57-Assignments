SELECT ship_country,round(avg(freight),2) as Freight_avg FROM northwind_db.orders
Group by ship_country
order by avg(freight) desc
limit 3;