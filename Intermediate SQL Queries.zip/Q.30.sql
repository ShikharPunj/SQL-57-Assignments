select a.customer_id,b.customer_id from customers as a
Left join orders as b
On a.customer_id=b.customer_id
Where b.customer_id is null;