SELECT product_id,product_name,units_in_stock,units_on_order,reorder_level,discontinued FROM northwind_db.products
Where (units_in_stock+units_on_order) <= reorder_level
and discontinued = 0;
