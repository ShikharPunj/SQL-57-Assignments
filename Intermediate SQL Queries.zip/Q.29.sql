Select a.employee_id,a.last_name,b.order_id,d.product_name,c.quantity From employees as a
Left Join orders as b
ON a.employee_id = b.employee_id
left join order_details as c
On b.order_id= c.order_id
Left Join products as d
On c.product_id = d.product_id
order by order_id;

