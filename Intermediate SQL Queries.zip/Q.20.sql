SELECT a.category_name,Count(b.product_name) FROM northwind_db.categories as a 
Inner Join products as b
ON a.category_id=b.category_id
Group By a.category_name
Order by Count(b.product_name) desc;