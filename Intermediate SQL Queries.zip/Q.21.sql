	SELECT Country,City,count(customer_id) FROM northwind_db.customers
    Group by Country,City;