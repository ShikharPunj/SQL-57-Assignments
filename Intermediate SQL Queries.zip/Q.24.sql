SELECT customer_id,company_name,region,Case when Region is null then 1 else 0
End as Final
FROM northwind_db.customers
Order by Final,region