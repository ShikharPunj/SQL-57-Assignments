SELECT order_id, ship_country,avg(freight) as l FROM northwind_db.orders
Where ship_country='France'
group by ship_country
order by l desc