SELECT product_id,product_name,units_in_stock,reorder_level FROM northwind_db.products
where units_in_stock < reorder_level
