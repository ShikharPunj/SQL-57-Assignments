
Select ship_country,round(avg(freight),2)  from orders
Where order_date between ('1997-05-07') and ('1998-05-06')
Group by ship_country
Order by avg(freight) desc
limit 3
